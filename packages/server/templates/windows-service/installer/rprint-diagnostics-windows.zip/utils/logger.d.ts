import winston from 'winston';
export declare const logger: winston.Logger;
