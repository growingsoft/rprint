import { Printer } from '../types';
export declare class PrinterUtils {
    /**
     * Get list of printers using PowerShell
     */
    static getPrinters(): Printer[];
    /**
     * Detect printer capabilities (simplified version)
     */
    private static detectCapabilities;
    /**
     * Map printer status to simplified status
     */
    private static mapPrinterStatus;
    /**
     * Print a file using pdf-to-printer or native Windows commands
     */
    static printFile(printerName: string, filePath: string, options: {
        copies?: number;
        colorMode?: 'color' | 'grayscale';
        duplex?: 'none' | 'short' | 'long';
        orientation?: 'portrait' | 'landscape';
    }): Promise<void>;
    /**
     * Print non-PDF files using native Windows printing
     */
    static printNonPdfFile(printerName: string, filePath: string): void;
}
