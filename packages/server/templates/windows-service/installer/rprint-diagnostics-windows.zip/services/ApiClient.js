"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApiClient = void 0;
const axios_1 = __importDefault(require("axios"));
const logger_1 = require("../utils/logger");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
class ApiClient {
    constructor(serverUrl, apiKey) {
        this.serverUrl = serverUrl;
        this.apiKey = apiKey;
        this.downloadDir = path_1.default.join(process.cwd(), 'downloads');
        if (!fs_1.default.existsSync(this.downloadDir)) {
            fs_1.default.mkdirSync(this.downloadDir, { recursive: true });
        }
        this.client = axios_1.default.create({
            baseURL: serverUrl,
            headers: {
                'X-API-Key': apiKey
            },
            timeout: 30000
        });
    }
    /**
     * Send heartbeat to server
     */
    async sendHeartbeat() {
        try {
            await this.client.post('/api/workers/heartbeat');
            logger_1.logger.debug('Heartbeat sent successfully');
        }
        catch (error) {
            logger_1.logger.error('Error sending heartbeat:', error.message);
            throw error;
        }
    }
    /**
     * Sync printers with server
     */
    async syncPrinters(printers) {
        try {
            const response = await this.client.post('/api/printers/sync', { printers });
            const syncedPrinters = response.data.printers || [];
            logger_1.logger.info(`Synced ${printers.length} printers with server`);
            return syncedPrinters;
        }
        catch (error) {
            logger_1.logger.error('Error syncing printers:', error);
            throw error;
        }
    }
    /**
     * Poll for pending print jobs
     */
    async pollPrintJobs(printerId) {
        try {
            const response = await this.client.get('/api/jobs/poll/pending', {
                params: { printerId }
            });
            return response.data.jobs || [];
        }
        catch (error) {
            logger_1.logger.error('Error polling print jobs:', error);
            return [];
        }
    }
    /**
     * Update print job status
     */
    async updateJobStatus(jobId, status, errorMessage) {
        try {
            await this.client.put(`/api/jobs/${jobId}/status`, {
                status,
                errorMessage
            });
            logger_1.logger.info(`Updated job ${jobId} status to ${status}`);
        }
        catch (error) {
            logger_1.logger.error('Error updating job status:', error.message);
            throw error;
        }
    }
    /**
     * Download print job file
     */
    async downloadJobFile(jobId, fileName) {
        try {
            const response = await this.client.get(`/api/jobs/${jobId}/download`, {
                responseType: 'arraybuffer'
            });
            const filePath = path_1.default.join(this.downloadDir, `${jobId}_${fileName}`);
            fs_1.default.writeFileSync(filePath, response.data);
            logger_1.logger.info(`Downloaded file to ${filePath}`);
            return filePath;
        }
        catch (error) {
            logger_1.logger.error('Error downloading job file:', error.message);
            throw error;
        }
    }
    /**
     * Clean up downloaded file
     */
    cleanupFile(filePath) {
        try {
            if (fs_1.default.existsSync(filePath)) {
                fs_1.default.unlinkSync(filePath);
                logger_1.logger.debug(`Cleaned up file: ${filePath}`);
            }
        }
        catch (error) {
            logger_1.logger.error('Error cleaning up file:', error.message);
        }
    }
}
exports.ApiClient = ApiClient;
//# sourceMappingURL=ApiClient.js.map