import { PrintJob, Printer } from '../types';
export declare class ApiClient {
    private client;
    private serverUrl;
    private apiKey;
    private downloadDir;
    constructor(serverUrl: string, apiKey: string);
    /**
     * Send heartbeat to server
     */
    sendHeartbeat(): Promise<void>;
    /**
     * Sync printers with server
     */
    syncPrinters(printers: Printer[]): Promise<any[]>;
    /**
     * Poll for pending print jobs
     */
    pollPrintJobs(printerId: string): Promise<PrintJob[]>;
    /**
     * Update print job status
     */
    updateJobStatus(jobId: string, status: string, errorMessage?: string): Promise<void>;
    /**
     * Download print job file
     */
    downloadJobFile(jobId: string, fileName: string): Promise<string>;
    /**
     * Clean up downloaded file
     */
    cleanupFile(filePath: string): void;
}
