"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrintService = void 0;
const printer_utils_1 = require("../utils/printer-utils");
const logger_1 = require("../utils/logger");
class PrintService {
    constructor(apiClient, pollInterval) {
        this.printers = [];
        this.printerMap = new Map();
        this.isRunning = false;
        this.pollTimers = new Map();
        this.apiClient = apiClient;
        this.pollInterval = pollInterval;
    }
    /**
     * Start the print service
     */
    async start() {
        logger_1.logger.info('Starting print service...');
        this.isRunning = true;
        // Initial printer sync
        await this.syncPrinters();
        // Start heartbeat
        this.startHeartbeat();
        // Start polling for each printer
        this.startPolling();
        // Periodically resync printers (every 5 minutes)
        setInterval(() => {
            this.syncPrinters();
        }, 5 * 60 * 1000);
        logger_1.logger.info('Print service started successfully');
    }
    /**
     * Stop the print service
     */
    stop() {
        logger_1.logger.info('Stopping print service...');
        this.isRunning = false;
        // Stop all polling timers
        this.pollTimers.forEach(timer => clearInterval(timer));
        this.pollTimers.clear();
        logger_1.logger.info('Print service stopped');
    }
    /**
     * Sync printers with server
     */
    async syncPrinters() {
        try {
            this.printers = printer_utils_1.PrinterUtils.getPrinters();
            logger_1.logger.info(`Found ${this.printers.length} printers`);
            if (this.printers.length > 0) {
                const syncedPrinters = await this.apiClient.syncPrinters(this.printers);
                // Update printer map with server-assigned IDs
                this.printerMap.clear();
                syncedPrinters.forEach((serverPrinter) => {
                    // Find matching local printer by name
                    const localPrinter = this.printers.find(p => p.name === serverPrinter.name);
                    if (localPrinter) {
                        // Add server ID to local printer
                        localPrinter.id = serverPrinter.id;
                        this.printerMap.set(serverPrinter.id, localPrinter);
                    }
                });
                logger_1.logger.info(`Mapped ${this.printerMap.size} printers with server IDs`);
            }
        }
        catch (error) {
            logger_1.logger.error('Error syncing printers:', error);
        }
    }
    /**
     * Start heartbeat timer
     */
    startHeartbeat() {
        // Send heartbeat every 30 seconds
        setInterval(async () => {
            if (!this.isRunning)
                return;
            try {
                await this.apiClient.sendHeartbeat();
            }
            catch (error) {
                logger_1.logger.error('Heartbeat failed:', error);
            }
        }, 30000);
        // Send initial heartbeat
        this.apiClient.sendHeartbeat().catch(err => {
            logger_1.logger.error('Initial heartbeat failed:', err);
        });
    }
    /**
     * Start polling for print jobs
     */
    startPolling() {
        if (this.printerMap.size === 0) {
            logger_1.logger.warn('No printers found to poll. Printer map is empty.');
            return;
        }
        // Poll for each printer using their server IDs
        this.printerMap.forEach((printer, printerId) => {
            logger_1.logger.info(`Setting up polling for printer: ${printer.name} (ID: ${printerId})`);
            const timer = setInterval(async () => {
                if (!this.isRunning)
                    return;
                logger_1.logger.debug(`Polling for jobs on printer: ${printer.name}`);
                await this.pollAndPrint(printerId, printer);
            }, this.pollInterval);
            this.pollTimers.set(printerId, timer);
        });
        logger_1.logger.info(`Started polling for ${this.printerMap.size} printers`);
    }
    /**
     * Poll for jobs and print them
     */
    async pollAndPrint(printerId, printer) {
        try {
            const jobs = await this.apiClient.pollPrintJobs(printerId);
            if (jobs.length > 0) {
                logger_1.logger.info(`Found ${jobs.length} job(s) for printer ${printer.name}`);
            }
            for (const job of jobs) {
                await this.processPrintJob(job, printer);
            }
        }
        catch (error) {
            logger_1.logger.error(`Error polling for printer ${printer.name}:`, error);
        }
    }
    /**
     * Process a single print job
     */
    async processPrintJob(job, printer) {
        let localFilePath = null;
        try {
            logger_1.logger.info(`Processing job ${job.id} for printer ${printer.name}`);
            // Update status to printing
            await this.apiClient.updateJobStatus(job.id, 'printing');
            // Download file
            localFilePath = await this.apiClient.downloadJobFile(job.id, job.fileName);
            // Print file
            if (job.mimeType === 'application/pdf') {
                await printer_utils_1.PrinterUtils.printFile(printer.name, localFilePath, {
                    copies: job.copies,
                    colorMode: job.colorMode,
                    duplex: job.duplex,
                    orientation: job.orientation
                });
            }
            else {
                // For non-PDF files, use native printing
                printer_utils_1.PrinterUtils.printNonPdfFile(printer.name, localFilePath);
            }
            // Update status to completed
            await this.apiClient.updateJobStatus(job.id, 'completed');
            logger_1.logger.info(`Successfully completed job ${job.id}`);
        }
        catch (error) {
            logger_1.logger.error(`Error processing job ${job.id}:`, error);
            await this.apiClient.updateJobStatus(job.id, 'failed', error.message);
        }
        finally {
            // Clean up downloaded file
            if (localFilePath) {
                this.apiClient.cleanupFile(localFilePath);
            }
        }
    }
}
exports.PrintService = PrintService;
//# sourceMappingURL=PrintService.js.map