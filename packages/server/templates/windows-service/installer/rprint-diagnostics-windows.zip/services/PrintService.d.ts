import { ApiClient } from './ApiClient';
export declare class PrintService {
    private apiClient;
    private pollInterval;
    private printers;
    private printerMap;
    private isRunning;
    private pollTimers;
    constructor(apiClient: ApiClient, pollInterval: number);
    /**
     * Start the print service
     */
    start(): Promise<void>;
    /**
     * Stop the print service
     */
    stop(): void;
    /**
     * Sync printers with server
     */
    private syncPrinters;
    /**
     * Start heartbeat timer
     */
    private startHeartbeat;
    /**
     * Start polling for print jobs
     */
    private startPolling;
    /**
     * Poll for jobs and print them
     */
    private pollAndPrint;
    /**
     * Process a single print job
     */
    private processPrintJob;
}
